/**
 * Provides basic example of stock market prediction with neural networks.
 */

package org.neuroph.contrib.samples.stockmarket;